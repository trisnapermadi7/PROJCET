<?php
$host = "localhost:3306"; // Default host dan port
$user = "root";           // Default user MySQL
$pass = "";               // Password kosong untuk instalasi default XAMPP
$db = "two_step_verification";

$conn = mysqli_connect($host, $user, $pass, $db);

// Periksa koneksi
// if (!$conn) {
//     die("Koneksi gagal: " . mysqli_connect_error());
// }
// echo "Koneksi berhasil!";
// 
?>
