<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            color: #fff;
            text-align: center;
        }

        header {
            background-color: #2d3436;
            padding: 20px 0;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
        }

        main {
            margin-top: 50px;
        }

        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #00cec9;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #00b894;
        }

        footer {
            margin-top: 50px;
            padding: 10px;
            background-color: #2d3436;
            color: #b2bec3;
            font-size: 0.9em;
        }

        footer a {
            color: #74b9ff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the Dashboard!</h1>
    </header>
    <main>
        <p>Hello, you have successfully logged in!</p>
        <a href="logout.php" class="button">Logout</a>
    </main>
    <footer>
        <p>&copy; 2024 My Dashboard. Built with <a href="https://www.w3schools.com/css/">CSS</a>.</p>
    </footer>
</body>
</html>
