<?php
session_start();
include 'conn.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $_SESSION['email']=$email;

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query($conn, $sql);
    $data = mysqli_fetch_array($query);

    if ($data && password_verify($password, $data['password'])) {
        $otp = rand(100000, 999999);
        $otp_expiry = date("Y-m-d H:i:s", strtotime("+3 minute"));
        $subject= "Your OTP for Login";
        $message="Your OTP is: $otp";

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'trisnapermadi7@gmail.com'; //host email 
        $mail->Password = 'qgyttwojzendjbnv'; // app password of your host email
        $mail->Port = 465;
        $mail->SMTPSecure = 'ssl';
        $mail->isHTML(true);
        $mail->setFrom('trisnapermadi7@gmail.com', 'Online Examination System');//Sender's Email & Name
        $mail->addAddress($email, $name); //Receiver's Email and Name
        $mail->Subject = ("$subject");
        $mail->Body = $message;
        $mail->send();

        $sql1 = "UPDATE users SET otp='$otp', otp_expiry='$otp_expiry' WHERE id=".$data['id'];
        $query1 = mysqli_query($conn, $sql1);

        $_SESSION['temp_user'] = ['id' => $data['id'], 'otp' => $otp];
        header("Location: otp_verification.php");
        exit();
    } else {
        ?>
        <script>
           alert("Invalid Email or Password. Please try again.");
                function navigateToPage() {
                    window.location.href = 'index.php';
                }
                window.onload = function() {
                    navigateToPage();
                }
        </script>
        <?php 
    
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #container {
            background: #fff;
            color: #333;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            padding: 30px;
            text-align: center;
        }

        input[type=text], input[type=password] {
            width: calc(100% - 20px);
            height: 40px;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        label {
            font-size: 18px;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            text-align: left;
        }

        form {
            width: 100%;
        }

        a {
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            color: #0984e3;
        }

        a:hover {
            cursor: pointer;
            color: #6c5ce7;
        }

        input[type=submit] {
            width: 100%;
            background-color: #0984e3;
            border: none;
            color: white;
            font-weight: bold;
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type=submit]:hover {
            background-color: #6c5ce7;
        }

        .signup {
            margin-top: 20px;
        }

        .signup a {
            color: #0984e3;
        }

        .signup a:hover {
            color: #6c5ce7;
        }
    </style>
</head>
<body>
    <div id="container">
        <h2>Login</h2>
        <form method="post" action="index.php">
            <label for="email">Email: </label>
            <input type="text" name="email" placeholder="Enter Your Email" required>

            <label for="password">Password: </label>
            <input type="password" name="password" placeholder="Enter Your Password" required>

            <input type="submit" name="login" value="Login">
            <p>Don't have an account? <a href="registration.php">Sign Up</a></p>
        </form>
    </div>
</body>
</html>